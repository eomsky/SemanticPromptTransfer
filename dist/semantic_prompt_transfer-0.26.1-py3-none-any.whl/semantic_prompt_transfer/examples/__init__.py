"""Packaged examples."""
