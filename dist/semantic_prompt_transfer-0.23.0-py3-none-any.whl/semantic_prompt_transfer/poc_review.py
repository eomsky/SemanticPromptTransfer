from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from .colab_runtime import EphemeralColabRuntime
from .config import DocumentScope
from .domain import CaseContext, CreditFact, DocumentKind, FileStatus
from .fewshot import FewShotSelector
from .llm import TextGenerator
from .orchestration import ReviewGenerationOrchestrator, ReviewGenerationResult
from .poc_processing import PocUploadProcessor, ShardedAttachmentRetriever


class PocCreditFactRepository:
    def __init__(self, runtime: EphemeralColabRuntime) -> None:
        self.runtime = runtime

    def load(self, tenant_id: str, case_id: str) -> list[CreditFact]:
        candidates = [
            row
            for row in self.runtime.registry.list_documents(tenant_id, case_id)
            if row.document_kind is DocumentKind.CREDIT_REPORT and row.status is FileStatus.READY
        ]
        if len(candidates) != 1:
            raise ValueError("exactly one ready credit report is required")
        document = candidates[0]
        if not document.derived_uri:
            raise RuntimeError("credit report derived path is missing")
        path = Path(document.derived_uri) / "credit_facts.json"
        if not path.is_file():
            raise RuntimeError("credit report facts are unavailable")
        value = json.loads(path.read_text(encoding="utf-8"))
        return [CreditFact.from_dict(row) for row in value.get("facts", [])]


class EphemeralReviewJobService:
    """Create quickly, execute in a FastAPI background task, then expose a DOCX."""

    def __init__(
        self,
        runtime: EphemeralColabRuntime,
        retriever: ShardedAttachmentRetriever,
        few_shots: FewShotSelector,
        generator: TextGenerator,
        upload_processor: PocUploadProcessor | None = None,
        *,
        loan_type: str = "운전자금",
        industry_code: str = "*",
        company_name: str | None = None,
    ) -> None:
        self.runtime = runtime
        self.facts = PocCreditFactRepository(runtime)
        self.generator = generator
        self.upload_processor = upload_processor
        self.loan_type = loan_type
        self.industry_code = industry_code
        self.company_name = company_name
        self.job_options: dict[str, dict[str, bool]] = {}
        self.orchestrator = ReviewGenerationOrchestrator(
            retriever,
            few_shots,
            registry=runtime.registry,
            llm=generator,
        )

    def start(
        self,
        tenant_id: str,
        case_id: str,
        *,
        generate_optional_artifacts: bool = False,
    ) -> dict[str, object]:
        documents = self.runtime.registry.list_documents(tenant_id, case_id)
        if not documents:
            raise ValueError("uploaded documents are required")
        credit_reports = [row for row in documents if row.document_kind is DocumentKind.CREDIT_REPORT]
        if len(credit_reports) != 1:
            raise ValueError("exactly one uploaded credit report is required")
        blocked = [
            row.filename
            for row in documents
            if row.status in {FileStatus.FAILED, FileStatus.DELETING, FileStatus.DELETED}
        ]
        if blocked:
            raise ValueError("remove failed or deleting uploads first: " + ", ".join(blocked))
        job = self.runtime.registry.create_job(tenant_id, case_id)
        self.job_options[job.job_id] = {
            "generate_optional_artifacts": bool(generate_optional_artifacts)
        }
        return job.to_dict()

    def run(self, job_id: str) -> ReviewGenerationResult:
        job = self.runtime.registry.get_job(job_id)
        case = CaseContext(
            job.tenant_id,
            job.case_id,
            self.loan_type,
            self.industry_code,
            self.company_name,
        )
        for document in self.runtime.registry.list_documents(job.tenant_id, job.case_id):
            if document.status is FileStatus.READY:
                continue
            if self.upload_processor is None:
                raise RuntimeError("upload processor is required for deferred document processing")
            scope = DocumentScope(job.tenant_id, job.case_id, document.document_id)

            def progress(status: FileStatus, percent: int | None, message: str | None) -> None:
                self.runtime.application.update_upload(
                    scope, status, progress=percent, message=message
                )

            try:
                self.upload_processor.process(
                    scope,
                    Path(document.storage_uri),
                    document.document_kind,
                    progress,
                )
            except Exception as exc:
                self.runtime.application.update_upload(
                    scope,
                    FileStatus.FAILED,
                    progress=0,
                    message="파일 처리에 실패했습니다.",
                    error=str(exc),
                )
                raise
        output = self.runtime.review_output_path(job.tenant_id, job.case_id, job_id)
        return self.orchestrator.generate(
            case,
            self.facts.load(job.tenant_id, job.case_id),
            None,
            output,
            job_id=job_id,
        )
