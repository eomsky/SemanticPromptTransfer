from __future__ import annotations

import re
import zipfile
from html import escape
from pathlib import Path
from typing import Iterable

from .domain import CaseContext, ReviewItem, ReviewSectionDraft
from .version import PACKAGE_VERSION


class OpinionDocumentBuilder:
    """Render the validated five-item review opinion as a Word document."""

    _citation = re.compile(r"\[?\s*(?:CR|ATT)_[a-f0-9]{20}\s*\]?", re.IGNORECASE)

    @classmethod
    def _visible_text(cls, text: str) -> str:
        value = cls._citation.sub("", str(text or ""))
        value = re.sub(r"\[\s*(?:,\s*)+\]", "", value)
        value = re.sub(r"\s+([.,;:])", r"\1", value)
        return re.sub(r"[ \t]{2,}", " ", value).strip()

    def build(
        self,
        case: CaseContext,
        sections: Iterable[ReviewSectionDraft],
        output_path: str | Path,
        *,
        title: str = "여신 심사의견",
    ) -> Path:
        try:
            from docx import Document
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            from docx.oxml import OxmlElement
            from docx.oxml.ns import qn
            from docx.shared import Cm, Pt
        except ImportError as exc:  # pragma: no cover - dependency error is environment-specific
            raise RuntimeError("python-docx is required for Word output") from exc

        by_item = {section.review_item: section for section in sections}
        missing = [item.value for item in ReviewItem.ordered() if item not in by_item]
        if missing:
            raise ValueError(f"review sections missing: {missing}")

        document = Document()
        section = document.sections[0]
        section.top_margin = Cm(1.9)
        section.bottom_margin = Cm(1.8)
        section.left_margin = Cm(2.1)
        section.right_margin = Cm(2.1)

        styles = document.styles
        for name in ("Normal", "Title", "Heading 1"):
            style = styles[name]
            style.font.name = "Arial"
            style.font.size = Pt(10.5 if name == "Normal" else 14 if name == "Heading 1" else 21)
            style._element.rPr.rFonts.set(qn("w:eastAsia"), "맑은 고딕")

        title_paragraph = document.add_paragraph()
        title_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title_paragraph.add_run(title)
        title_run.bold = True
        title_run.font.size = Pt(21)
        title_run.font.name = "Arial"
        title_run._element.rPr.rFonts.set(qn("w:eastAsia"), "맑은 고딕")

        info = document.add_table(rows=4, cols=2)
        info.style = "Table Grid"
        labels = (
            ("심사건", case.case_id),
            ("여신유형", case.loan_type),
            ("산업분류", case.industry_code),
            ("대상기업", case.company_name or "미지정"),
        )
        for row, (label, value) in zip(info.rows, labels, strict=True):
            row.cells[0].text = label
            row.cells[1].text = value
            row.cells[0].paragraphs[0].runs[0].bold = True

        document.add_paragraph()
        korean_labels = ("가", "나", "다", "라", "마")
        for label, item in zip(korean_labels, ReviewItem.ordered(), strict=True):
            heading = document.add_paragraph(style="Heading 1")
            heading.paragraph_format.space_before = Pt(12)
            heading.paragraph_format.space_after = Pt(4)
            run = heading.add_run(f"{label}. {item.title}")
            run.bold = True
            body = document.add_paragraph(self._visible_text(by_item[item].text))
            body.paragraph_format.line_spacing = 1.25
            body.paragraph_format.space_after = Pt(6)

        trace_heading = document.add_heading("근거 추적 정보", level=1)
        trace_heading.paragraph_format.keep_with_next = True
        trace = document.add_table(rows=1, cols=2)
        trace.style = "Table Grid"
        trace.rows[0].cells[0].text = "심사항목"
        trace.rows[0].cells[1].text = "사용 근거"
        for item in ReviewItem.ordered():
            cells = trace.add_row().cells
            cells[0].text = f"{item.value}. {item.title}"
            identifiers = by_item[item].evidence_ids
            credit_count = sum(value.upper().startswith("CR_") for value in identifiers)
            attachment_count = sum(value.upper().startswith("ATT_") for value in identifiers)
            labels = []
            if credit_count:
                labels.append(f"신용조사서 {credit_count}건")
            if attachment_count:
                labels.append(f"첨부자료 {attachment_count}건")
            cells[1].text = " / ".join(labels) or "없음"

        footer = section.footer.paragraphs[0]
        footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
        footer.add_run(f"SemanticPromptTransfer v{PACKAGE_VERSION} · 근거 추적형 생성문서")

        settings = document.settings.element
        update_fields = OxmlElement("w:updateFields")
        update_fields.set(qn("w:val"), "true")
        settings.append(update_fields)

        target = Path(output_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        document.save(target)
        return target
    def build_minimal(
        self,
        case: CaseContext,
        sections: Iterable[ReviewSectionDraft],
        output_path: str | Path,
        *,
        title: str = "여신 심사의견",
    ) -> Path:
        """Dependency-light OOXML fallback used when the normal renderer cannot complete."""
        rows = list(sections)
        by_item = {section.review_item: section for section in rows}
        paragraphs = [
            title,
            f"심사건: {case.case_id}",
            f"여신유형: {case.loan_type}",
            f"산업분류: {case.industry_code}",
            f"대상기업: {case.company_name or '미지정'}",
        ]
        for item in ReviewItem.ordered():
            paragraphs.append(f"{item.value}. {item.title}")
            paragraphs.append(self._visible_text(by_item[item].text) if item in by_item else "추가 자료 확인이 필요합니다.")
        body = "".join(
            f'<w:p><w:r><w:t xml:space="preserve">{escape(text)}</w:t></w:r></w:p>'
            for text in paragraphs
        )
        document_xml = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            f'<w:body>{body}<w:sectPr/></w:body></w:document>'
        )
        content_types = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
            '</Types>'
        )
        rels = (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
            '</Relationships>'
        )
        target = Path(output_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("[Content_Types].xml", content_types)
            archive.writestr("_rels/.rels", rels)
            archive.writestr("word/document.xml", document_xml)
        return target

