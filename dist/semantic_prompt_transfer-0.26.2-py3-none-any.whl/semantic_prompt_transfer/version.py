"""Single runtime version source used by APIs, health checks, and exports."""

PACKAGE_VERSION = "0.26.2"
__version__ = PACKAGE_VERSION
